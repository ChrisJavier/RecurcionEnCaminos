package caminos;

public class Nodo {
	
	private String nombreNodo;
	
	

}
